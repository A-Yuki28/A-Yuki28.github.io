//21FI003 網中優希
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls";
import * as dat from "dat.gui";
import { RectAreaLightHelper } from 'three/examples/jsm/helpers/RectAreaLightHelper.js';

class ThreeJSContainer {
    private scene: THREE.Scene;
    private geometry: THREE.BufferGeometry;
    private material: THREE.Material;
    private TorusKno: THREE.Mesh;
    private light: THREE.Light;
    private particles:THREE.Points;
    private particles2:THREE.Points;
    constructor() {

    }

    // 画面部分の作成(表示する枠ごとに)*
    public createRendererDOM = (width: number, height: number, cameraPos: THREE.Vector3) => {
        let renderer = new THREE.WebGLRenderer();
        renderer.setSize(width, height);
        renderer.setClearColor(new THREE.Color(0x000000));

        //カメラの設定
        let camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
        camera.position.copy(cameraPos);
        camera.lookAt(new THREE.Vector3(0, 0, 0));

        let orbitControls = new OrbitControls(camera, renderer.domElement);

        this.createScene();
        // 毎フレームのupdateを呼んで，render
        // reqestAnimationFrame により次フレームを呼ぶ
        let render: FrameRequestCallback = (time) => {
            orbitControls.update();

            renderer.render(this.scene, camera);
            requestAnimationFrame(render);
        }
        requestAnimationFrame(render);

        renderer.domElement.style.cssFloat = "left";
        renderer.domElement.style.margin = "10px";
        return renderer.domElement;
    }

    // シーンの作成(全体で1回)
    private createScene = () => {
        this.scene = new THREE.Scene();

        this.geometry = new THREE.BoxGeometry(1, 1, 1);
        this.material = new THREE.MeshLambertMaterial({ color: 0x55ff00 });
        this.TorusKno = new THREE.Mesh(this.geometry, this.material);
        //this.TorusKno.castShadow = true;
        //this.scene.add(this.TorusKno);

        //コントロール
        const gui = new dat.GUI()


        /**
         * Lights
         */
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);//(色,光の強さ)
        this.scene.add(ambientLight);

        gui.add(ambientLight,'intensity').min(0).max(1).step(0.01);

        const directionalLight = new THREE.DirectionalLight(0x00fffc,0.3);
        directionalLight.position.set(1,0.25,0);
        this.scene.add(directionalLight);

        const hemisphereLight = new THREE.HemisphereLight(0xff0000,0x0000ff,0.3);//(片側の色、もう片方の色、強さ)
        this.scene.add(hemisphereLight);

        const pointLight = new THREE.PointLight(0xff9000,0.5,10,2);//(色、強さ、減衰距離,減衰速度)
        pointLight.position.set(0.5,-0.5,1);
        this.scene.add(pointLight);

        const rectAreaLight = new THREE.RectAreaLight(0x4e00ff,2,1,1);
        rectAreaLight.position.set(-1.5,0,1.5);
        rectAreaLight.lookAt(new THREE.Vector3())
        this.scene.add(rectAreaLight);

        const spotLight = new THREE.SpotLight(0x78ff00,0.5,6,Math.PI*0.1, 0.25,1);
        spotLight.position.set(0,2,3);
        this.scene.add(spotLight);
        

        spotLight.target.position.x = - 0.75;
        this.scene.add(spotLight.target);

        //Helpers
        const hemisphereLightHelper = new THREE.HemisphereLightHelper(hemisphereLight, 0.2)
        this.scene.add(hemisphereLightHelper)

        const directionalLightHelper = new THREE.DirectionalLightHelper(directionalLight, 0.2)
        this.scene.add(directionalLightHelper)

        const pointLightHelper = new THREE.PointLightHelper(pointLight, 0.2)
        this.scene.add(pointLightHelper)

        const spotLightHelper = new THREE.SpotLightHelper(spotLight)
        this.scene.add(spotLightHelper)

        const rectAreaLightHelper = new RectAreaLightHelper(rectAreaLight)
        this.scene.add(rectAreaLightHelper)

        directionalLightHelper.visible=false
        hemisphereLightHelper.visible=false
        pointLightHelper.visible = false
        spotLightHelper.visible = false
        rectAreaLightHelper.visible=false
        /**
         * Objects
         */
        // Material
        const material = new THREE.MeshStandardMaterial()
        material.roughness = 0.4

        // Objects
        const sphere = new THREE.Mesh(
            new THREE.SphereGeometry(0.5, 32, 32),
            material
        )
        //sphere.position.x = - 1.5

        const TorusKno = new THREE.Mesh(
            new THREE.TorusKnotGeometry(0.4,0.2),
            material
        )
        TorusKno.position.y = 0.1
        const torus = new THREE.Mesh(
            new THREE.TorusGeometry(0.3, 0.2, 32, 64),
            material
        )
        torus.position.x = 1.5

        const plane = new THREE.Mesh(
            new THREE.PlaneGeometry(5, 5),
            material
        )
        plane.rotation.x = - Math.PI * 0.5
        plane.position.y = - 0.65
        
        
    

        this.scene.add(sphere, TorusKno, plane)
        
        

        //パーティクルの波
        /**
         * Textures
         */
        const textureLoader = new THREE.TextureLoader()
        const particleTexture = textureLoader.load('2.png')//テクスチャをロード

        const simpleShadow = textureLoader.load('simpleShadow.jpg')
        const sphereShadow = new THREE.Mesh(
            new THREE.PlaneGeometry(1.5, 1.5),
            new THREE.MeshBasicMaterial({
                color: 0x000000,
                transparent: true,
                alphaMap: simpleShadow
            })
        )
        sphereShadow.rotation.x = - Math.PI * 0.5
        sphereShadow.position.y = plane.position.y + 0.01

        this.scene.add(sphere, sphereShadow, plane)


        /**
        *Particles
        */
        //Geometry
        const particlesGeometry = new THREE.BufferGeometry()
        const count = 30000//パーティクルの数

        const positions = new Float32Array(count * 3)//配列
        const colors = new Float32Array(count * 3)

        for(let i = 0;i < count * 3;i++){
            positions[i] = (Math.random() - 0.5) * 10//-0.5～0.5までの値を入れる
            colors[i]=Math.random()//0-1の値が入る
        }
        //パーティクルのposiyionに座標を設定する,設定する属性の名前をidとして、値として持つ
        particlesGeometry.setAttribute('position' ,new THREE.BufferAttribute(positions,3))//先頭から3つずつ値を取って１つの要素(座標)として扱う
        particlesGeometry.setAttribute('color',new THREE.BufferAttribute(colors,3))//頂点に色を設定

        //Material
        const particlesMaterial = new THREE.PointsMaterial()
        particlesMaterial.size = 0.1//パーティクルのサイズ
        particlesMaterial.sizeAttenuation = true//パーティクルを近くのパーティクルよりも小さくするかどうかを指定する
        particlesMaterial.color = new THREE.Color('#ff88cc')//カラーをピンクに
        //particlesMaterial.map = particleTexture//テクスチャからのデータを使用してポイントの色を設定します
        particlesMaterial.transparent = true
        particlesMaterial.alphaMap = particleTexture//アルファマップはグレースケールのテクスチャで、表面全体の不透明度をコントロールする
        //particlesMaterial.alphaTest = 0.001
        /*alphaTest は 0 から 1 までの値で、WebGL がピクセルの透明度に応じてピクセルをレンダリングしない時期を認識できるようになります
        **この値は 0 で、ピクセルはいずれにせよレンダリングされます。0.001 のような小さな値を使用すると、アルファ値が 0 の場合、
        ピクセルはレンダリングされません：
        */
        //particlesMaterial.depthtest = false//深度テスト
        particlesMaterial.depthWrite = false//WebGLに深度バッファにパーティクルを書き込まないように指示
        particlesMaterial.blending = THREE.AdditiveBlending//blendingプロパティをTHREE.AdditiveBlendingに変更.ピクセルの色が重なり彩度が高くなる
        particlesMaterial.vertexColors = true//頂点カラーを有効にする

        //Poinsts
        this.particles = new THREE.Points(particlesGeometry,particlesMaterial)//パーティクルはThree.Pointsで作る
        this.particles.position.y=-1
        //this.particles.rotation.x=Math.PI/2  
        this.scene.add(this.particles)
  

        /**
         * Animate
         */
        const clock = new THREE.Clock()//時計


        //ライトの設定
        // this.light = new THREE.DirectionalLight(0xffffff);
        // let lvec = new THREE.Vector3(1, 1, 1).normalize();
        // this.light.position.set(lvec.x, lvec.y, lvec.z);
        // this.scene.add(this.light);

        // 毎フレームのupdateを呼んで，更新
        // reqestAnimationFrame により次フレームを呼ぶ
        let update: FrameRequestCallback = (time) => {
            this.TorusKno.rotateX(0.01);
            
            const elapsedTime = clock.getElapsedTime()//経過時間取得

        // Update the sphere
        sphere.position.x = Math.cos(elapsedTime) * 1.5
        sphere.position.z = Math.sin(elapsedTime) * 1.5
        sphere.position.y = Math.abs(Math.sin(elapsedTime * 3))

            // Update objects
            sphere.rotation.y = 0.1 * elapsedTime
            TorusKno.rotation.y = 0.1 * elapsedTime
            torus.rotation.y = 0.1 * elapsedTime

            sphere.rotation.x = 0.15 * elapsedTime
            //TorusKno.rotation.x = 0.15 * elapsedTime
            torus.rotation.x = 0.15 * elapsedTime

            // Update the shadow
            sphereShadow.position.x = sphere.position.x
            sphereShadow.position.z = sphere.position.z
            sphereShadow.material.opacity = (1 - sphere.position.y) * 0.3

           
            // Update particles
            //particles.rotation.y = elapsedTime * 0.2//y軸回転
            let geom = <THREE.BufferGeometry>this.particles.geometry
            let pos = geom.getAttribute('position');
           
            for(let i=0; i < count; i++){
                 const i3 = i * 3//positionの要素の１番目にあたる番号、y座標にアクセススト時はi3+1番目の要素を参照すればよい
                 const x = this.particles.geometry.attributes.position.array[i3]//x座標を参照して波を作る.パーティクルの数が多いとシェーダーを使う方が良い
                
                pos.setY(i,0.2*Math.sin((elapsedTime + x)*4))
            }
            // this.particles.geometry.setAttribute('position' ,new THREE.BufferAttribute(positions,3))
            this.particles.geometry.attributes.position.needsUpdate = true//ジオメトリが変更されたことを通知しないと変化しない
                    requestAnimationFrame(update);
            }
        requestAnimationFrame(update);
    }
}

window.addEventListener("DOMContentLoaded", init);

function init() {
    let container = new ThreeJSContainer();

    let viewport = container.createRendererDOM(640, 480, new THREE.Vector3(2, 2, 4));
    document.body.appendChild(viewport);
}
